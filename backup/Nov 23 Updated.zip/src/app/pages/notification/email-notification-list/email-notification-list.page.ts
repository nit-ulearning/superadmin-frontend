import { Component, OnInit } from '@angular/core';
import { ModalController, ToastController,AlertController } from '@ionic/angular';
import { ModalPage } from '../../modal/modal.page';
import { CommonUtils } from 'src/app/services/common-utils/common-utils';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';
import * as moment from 'moment';

@Component({
  selector: 'app-email-notification-list',
  templateUrl: './email-notification-list.page.html',
  styleUrls: ['./email-notification-list.page.scss'],
})
export class EmailNotificationListPage implements OnInit {
getTemplateList_api;
TemplatesList;
private templateList_get:Subscription;
  constructor(
    public toastController: ToastController,
    private modalController : ModalController,
    private http : HttpClient,
    private commonUtils: CommonUtils, // common functionlity come here
     private router: Router,
    private activatedRoute : ActivatedRoute,
    private alertController:AlertController,
  ) { }

  // Variables start
  statusChange = true;
  isListLoading = false;
  skeleton = []
  // Variables end

  ngOnInit() {
    this.commonFunction();
  }

  // getTemplateList start
  getTemplateList()
  {
    console.log("HHH");
    this.templateList_get = this.http.get(this.getTemplateList_api).subscribe(
        (res:any) => {
          console.log("Get template for  >", res);
          this.skeleton = res; 
          console.log("Get template for length",this.skeleton);

        },
        errRes => {
           console.log("Get template for  >", errRes);  
        }
      );    
  }
  // getTemplateList end
  commonFunction(){
    this.getTemplateList_api = 'emailTemplate/getAll/template';
    this.getTemplateList();
  }
  
  clickEditBtn(item)
  {
    console.log("item",item);
  }
  // Delete aleart start
  async presentAlert() {
    const alert = await this.alertController.create({
      cssClass: 'aleart-popupBox',
      header: 'Delete',
      message: 'Are you sure want to delete this item?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'popup-cancel-btn',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Okay',
          cssClass: 'popup-ok-btn',
          handler: () => {
            console.log('Confirm Okay');
            this.clickActionBtn('', 'delete');
          }
        }
      ]
    });

    await alert.present();
  }
  // Delete aleart end

  async presentToast(_msg, _type) {
    const toast = await this.toastController.create({
      message: _msg,
      duration: 2000,
      cssClass:"my-tost-custom-class" +_type,
    });
    toast.present();
  }

  clickActionBtn(_value, _identifier) {
    this.getTemplateList();
  }


}
