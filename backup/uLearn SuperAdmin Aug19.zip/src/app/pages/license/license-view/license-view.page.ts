import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-license-view',
  templateUrl: './license-view.page.html',
  styleUrls: ['./license-view.page.scss'],
})
export class LicenseViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
