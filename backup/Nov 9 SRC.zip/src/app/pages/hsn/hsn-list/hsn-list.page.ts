import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hsn-list',
  templateUrl: './hsn-list.page.html',
  styleUrls: ['./hsn-list.page.scss'],
})
export class HsnListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
