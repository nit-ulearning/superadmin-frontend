import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-hsn',
  templateUrl: './add-hsn.page.html',
  styleUrls: ['./add-hsn.page.scss'],
})
export class AddHsnPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
