import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracking-view',
  templateUrl: './tracking-view.page.html',
  styleUrls: ['./tracking-view.page.scss'],
})
export class TrackingViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
