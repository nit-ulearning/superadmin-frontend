import { OnlyNumberDirective } from './only-number.directive';

describe('OnlyNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyNumberDirective();
    expect(directive).toBeTruthy();
  });
});
