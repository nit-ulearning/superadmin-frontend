export const environment = {
  production: true,
  apiMaster:'1',
  apiUrl:'http://52.52.238.57:5000/api/v1',
  fileUrl:'http://52.52.238.57:5000/api/v1'
};
