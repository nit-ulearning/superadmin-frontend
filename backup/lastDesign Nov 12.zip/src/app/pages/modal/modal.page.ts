import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.page.html',
  styleUrls: ['./modal.page.scss'],
})
export class ModalPage implements OnInit {

  // Variable start
  get_identifier;
  get_item;
  get_array;
  heder_title;
  api_url;
  hide = true;
  hide2 = true;
  hide3 = true;
  model: any = {};
  Validity = [
    {value: 'Years', viewValue: 'Years'},
    {value: 'Months', viewValue: 'Months'},
    {value: 'Days', viewValue: 'Days'},
  ];
  constructor(
    private navParams : NavParams,
    private modalController : ModalController,
  ) { }

  ngOnInit() {
    this.get_identifier =  this.navParams.get('identifier');
    this.get_item =  this.navParams.get('modalForm_item');
    this.get_array =  this.navParams.get('modalForm_array');

    console.log('get_identifier', this.get_identifier);
    console.log('get_item', this.get_item);
    console.log('get_array', this.get_array);

    if(this.get_identifier == 'suspend_package_modal') {
      this.heder_title = 'Package Suspend';
    }  
    else if(this.get_identifier == 'restore_package_modal') 
    {
      this.heder_title = 'Package Restore';
    }
    else if(this.get_identifier == 'end_package_modal') 
    {
      this.heder_title = 'Package End';
    }
    else if(this.get_identifier == 'restore_licence_modal') 
    {
      this.heder_title = 'Licence Restore';
    }
    else if(this.get_identifier == 'end_licence_modal') 
    {
      this.heder_title = 'Licence  Expiry';
    }
    else if(this.get_identifier == 'renew_licence_modal') 
    {
      this.heder_title = 'Licence  Renewal';
    }
    else if(this.get_identifier == 'suspend_licence_modal') 
    {
      this.heder_title = 'Licence  Suspension';
    }
    else if(this.get_identifier == 'extend_licence_modal') 
    {
      this.heder_title = 'Licence  Extension';
    }
    else if(this.get_identifier == 'changepassword_modal') 
    {
      this.heder_title = 'Change Your Password';
    }
    else if(this.get_identifier == 'AddTemplate_modal') 
    {
      this.heder_title = 'Add Template For';
    }
    else if(this.get_identifier == 'AddDefault_modal') 
    {
      this.heder_title = 'Add Set Default';
    }
    else if(this.get_identifier == 'AddSmsTemplate_modal') 
    {
      this.heder_title = 'Add Template For';
    }
    else if(this.get_identifier == 'choseHeader_modal') 
    {
      this.heder_title = 'Add Header Id';
    }
    else if(this.get_identifier == 'add_Sms_default_modal') 
    {
      this.heder_title = 'Add Set Default';
    }

            
          
        
      
    

  }

  // close modal
  closeModal() {
    // this.modalController.dismiss(this.arrayList);
    this.modalController.dismiss();
  }

}