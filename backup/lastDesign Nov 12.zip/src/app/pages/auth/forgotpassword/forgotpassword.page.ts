import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.page.html',
  styleUrls: ['./forgotpassword.page.scss'],
})
export class ForgotpasswordPage implements OnInit {
  isDisabled=true;
  hide = true;
  constructor(
    public menuCtrl: MenuController,
  ) { }

  ngOnInit() {
    
  }
  getCode()
  {
    this.isDisabled=false;
  }
  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

}
