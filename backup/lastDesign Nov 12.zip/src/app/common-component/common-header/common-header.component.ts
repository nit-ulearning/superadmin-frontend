import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { ModalPage } from 'src/app/pages/modal/modal.page';

@Component({
  selector: 'common-header',
  templateUrl: './common-header.component.html',
  styleUrls: ['./common-header.component.scss'],
})
export class CommonHeaderComponent implements OnInit {

  showSearch: boolean = false;
  constructor(
    private navCtrl : NavController,
    private modalController : ModalController,
  ) { }

  ngOnInit() {}
// ..... Restore licence modal start ......
async changePassword(_identifier, _item, _items) {
  // console.log('_identifier >>', _identifier);
  let changePassword_modal;
  changePassword_modal = await this.modalController.create({
  component: ModalPage,
  cssClass: 'mymodalClass small',
  componentProps: { 
    identifier: _identifier,
    modalForm_item: _item,
    modalForm_array: _items
  }
  });
  
  // modal data back to Component
  changePassword_modal.onDidDismiss()
  .then((getdata) => {
  console.log('getdata >>>>>>>>>>>', getdata);
  if(getdata.data == 'submitClose'){
    /* this.onListData(this.listing_url, this.displayRecord, this.pageNo, this.api_parms, this.searchTerm, this.cherecterSearchTerm, this.sortColumnName, this.sortOrderName, this.advanceSearchParms, this.urlIdentifire);  */
  }
  
  });
  
  return await changePassword_modal.present();
  }
  // Restore licence modal end 
  showSearchBox(_item) {
    console.log('showSearch>>', this.showSearch);
    if(this.showSearch == false) {
      this.showSearch = true;
    }else{
      this.showSearch = false;
    }
  }

  // Goto page start
  goToPage(_url, _item){
    console.log('goToPage _url >', _url);
    console.log('goToPage _item >', _item);
    // this.router.navigateByUrl(_url);

    this.navCtrl.navigateRoot(_url);
  }

}
