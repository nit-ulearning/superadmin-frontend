export const environment = {
  production: true,
  apiMaster:'1',
  apiUrl:'http://65.1.66.115:8085/dev',
  fileUrl:'http://65.1.66.115:8085/dev'
};
