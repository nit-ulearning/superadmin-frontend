import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-permission',
  templateUrl: './role-permission.page.html',
  styleUrls: ['./role-permission.page.scss'],
})
export class RolePermissionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
