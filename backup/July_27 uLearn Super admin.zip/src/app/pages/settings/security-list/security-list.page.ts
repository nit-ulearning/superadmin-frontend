import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-security-list',
  templateUrl: './security-list.page.html',
  styleUrls: ['./security-list.page.scss'],
})
export class SecurityListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
