import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscription-package-list',
  templateUrl: './subscription-package-list.page.html',
  styleUrls: ['./subscription-package-list.page.scss'],
})
export class SubscriptionPackageListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
