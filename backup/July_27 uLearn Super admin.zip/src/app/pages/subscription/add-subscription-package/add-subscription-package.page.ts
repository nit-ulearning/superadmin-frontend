import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-subscription-package',
  templateUrl: './add-subscription-package.page.html',
  styleUrls: ['./add-subscription-package.page.scss'],
})
export class AddSubscriptionPackagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
