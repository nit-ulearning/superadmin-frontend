import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-license-list',
  templateUrl: './license-list.page.html',
  styleUrls: ['./license-list.page.scss'],
})
export class LicenseListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
