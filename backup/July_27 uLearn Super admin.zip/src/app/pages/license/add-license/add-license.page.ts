import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-license',
  templateUrl: './add-license.page.html',
  styleUrls: ['./add-license.page.scss'],
})
export class AddLicensePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
