import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-email-notification',
  templateUrl: './add-email-notification.page.html',
  styleUrls: ['./add-email-notification.page.scss'],
})
export class AddEmailNotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
