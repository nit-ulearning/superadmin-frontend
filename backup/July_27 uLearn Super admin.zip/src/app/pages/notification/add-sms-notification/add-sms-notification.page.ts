import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sms-notification',
  templateUrl: './add-sms-notification.page.html',
  styleUrls: ['./add-sms-notification.page.scss'],
})
export class AddSmsNotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
