import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-notification-list',
  templateUrl: './email-notification-list.page.html',
  styleUrls: ['./email-notification-list.page.scss'],
})
export class EmailNotificationListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
