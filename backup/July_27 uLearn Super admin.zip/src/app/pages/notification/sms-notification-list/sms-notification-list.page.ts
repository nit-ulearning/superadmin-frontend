import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sms-notification-list',
  templateUrl: './sms-notification-list.page.html',
  styleUrls: ['./sms-notification-list.page.scss'],
})
export class SmsNotificationListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
