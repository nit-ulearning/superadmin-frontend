import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-notification',
  templateUrl: './add-notification.page.html',
  styleUrls: ['./add-notification.page.scss'],
})
export class AddNotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
